using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IronBrew2.Bytecode_Library.IR;
using IronBrew2.Obfuscator;

namespace IronBrew2.Bytecode_Library.Bytecode
{
	public class Serializer
	{
		private ObfuscationContext  _context;
		private ObfuscationSettings _settings;
		private Random   _r          = new Random();
		private Encoding _fuckingLua = Encoding.GetEncoding(28591);

		public Serializer(ObfuscationContext context, ObfuscationSettings settings)
		{
			_context  = context;
			_settings = settings;
		}

		// XOR a 32-bit word against the full 32-bit PrimaryXorKey.
		// Previously every byte was individually cast to (byte)PrimaryXorKey,
		// silently discarding the upper 24 bits and reducing key strength to 8 bits.
		private int XorWord(int value) => value ^ _context.PrimaryXorKey;

		public byte[] SerializeLChunk(Chunk chunk, bool factorXor = true)
		{
			var bytes = new List<byte>();

			// Write a single byte, XOR'd with the low byte of the key only where
			// needed for single-byte fields (ParameterCount, type tags).
			// These are inherently 8-bit fields so we use the low byte intentionally.
			void WriteByte(byte b)
			{
				if (factorXor)
					b ^= (byte)(_context.PrimaryXorKey & 0xFF);
				bytes.Add(b);
			}

			// Write a raw byte array with optional endian correction.
			// Does NOT apply XOR here — callers that need XOR use WriteInt32/WriteWord.
			void WriteRaw(byte[] b, bool checkEndian = true)
			{
				if (!BitConverter.IsLittleEndian && checkEndian)
					b = b.Reverse().ToArray();
				bytes.AddRange(b);
			}

			// Write a 32-bit integer, applying full 32-bit XOR when factorXor is set.
			void WriteInt32(int i)
			{
				if (factorXor) i = XorWord(i);
				WriteRaw(BitConverter.GetBytes(i));
			}

			// Write a 32-bit integer without XOR (used for length prefixes that the
			// VM deserializer reads before XOR is applied).
			void WriteInt32Raw(int i) => WriteRaw(BitConverter.GetBytes(i));

			void WriteNumber(double d)
			{
				byte[] raw = BitConverter.GetBytes(d);
				if (factorXor)
				{
					// XOR the double as two 32-bit words so the full key is used
					int lo = BitConverter.ToInt32(raw, 0) ^ _context.PrimaryXorKey;
					int hi = BitConverter.ToInt32(raw, 4) ^ _context.PrimaryXorKey;
					WriteRaw(BitConverter.GetBytes(lo));
					WriteRaw(BitConverter.GetBytes(hi));
				}
				else
				{
					WriteRaw(raw);
				}
			}

			void WriteString(string s)
			{
				byte[] sBytes = _fuckingLua.GetBytes(s);
				// Length prefix is NOT XOR'd — the VM reads it raw to know how many
				// bytes to pull, then XORs the content separately via gString
				WriteInt32Raw(sBytes.Length);
				// String content is XOR'd byte-by-byte in gString using the key,
				// so we store it already XOR'd here
				if (factorXor)
					foreach (byte b in sBytes) bytes.Add((byte)(b ^ (_context.PrimaryXorKey & 0xFF)));
				else
					bytes.AddRange(sBytes);
			}

			void WriteBool(bool b)
			{
				// Booleans are a single byte — use low-byte XOR intentionally
				WriteByte(b ? (byte)1 : (byte)0);
			}

			int[] SerializeInstruction(Instruction inst)
			{
				inst.UpdateRegisters();

				if (inst.InstructionType == InstructionType.Data)
					return new[] { _r.Next(), inst.Data };

				var cData  = inst.CustomData;
				int opCode = (int)inst.OpCode;

				if (cData != null)
				{
					var virtualOpcode = cData.Opcode;
					opCode = cData.WrittenOpcode?.VIndex ?? virtualOpcode.VIndex;
					virtualOpcode?.Mutate(inst);
				}

				int a = inst.A;
				int b = inst.B;
				int c = inst.C;

				int result_i1 = 0;
				int result_i2 = 0;

				if (inst.InstructionType == InstructionType.AsBx || inst.InstructionType == InstructionType.AsBxC)
					b += 1048575;

				result_i1 |= (byte)inst.InstructionType;
				result_i1 |= ((a & 0x1FF) << 2);
				result_i1 |= ((b & 0x1FF) << (2 + 9));
				result_i1 |= (c           << (2 + 9 + 9));

				result_i2 |= opCode;
				result_i2 |= (b << 11);

				return new[] { result_i1, result_i2 };
			}

			chunk.UpdateMappings();

			for (int i = 0; i < (int)ChunkStep.StepCount; i++)
			{
				switch (_context.ChunkSteps[i])
				{
					case ChunkStep.ParameterCount:
						WriteByte(chunk.ParameterCount);
						break;

					case ChunkStep.Constants:
						WriteInt32(chunk.Constants.Count);
						foreach (Constant c in chunk.Constants)
						{
							WriteByte((byte)_context.ConstantMapping[(int)c.Type]);
							switch (c.Type)
							{
								case ConstantType.Boolean: WriteBool(c.Data);   break;
								case ConstantType.Number:  WriteNumber(c.Data); break;
								case ConstantType.String:  WriteString(c.Data); break;
							}
						}
						break;

					case ChunkStep.Instructions:
						WriteInt32(chunk.Instructions.Count);
						foreach (Instruction ins in chunk.Instructions)
						{
							int[] arr = SerializeInstruction(ins);
							// Instruction words get an additional layer: their own XOR keys
							// on top of the primary key applied by WriteInt32
							WriteInt32(arr[0] ^ _context.IXorKey1);
							WriteInt32(arr[1] ^ _context.IXorKey2);
						}
						break;

					case ChunkStep.Functions:
						WriteInt32(chunk.Functions.Count);
						foreach (Chunk c in chunk.Functions)
							bytes.AddRange(SerializeLChunk(c, false));
						break;

					case ChunkStep.LineInfo when _settings.PreserveLineInfo:
						WriteInt32(chunk.Instructions.Count);
						foreach (var instr in chunk.Instructions)
							WriteInt32(instr.Line);
						break;
				}
			}

			return bytes.ToArray();
		}
	}
}
