using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;
using IronBrew2.Obfuscator;
using IronBrew2.Obfuscator.Encryption;
using IronBrew2.Obfuscator.VM_Generation;

namespace IronBrew2
{
    class Program
    {
        static void PrintHelp()
        {
            Console.WriteLine("IronBrew2 CLI - Lua 5.1 Bytecode VM Obfuscator");
            Console.WriteLine();
            Console.WriteLine("Usage: ironbrew <input.lua> [output.lua] [options]");
            Console.WriteLine();
            Console.WriteLine("Options:");
            Console.WriteLine("  --luac <path>       Path to luac5.1 executable (default: luac5.1.exe)");
            Console.WriteLine("  --mutate            Enable opcode mutations (default: on)");
            Console.WriteLine("  --no-mutate         Disable opcode mutations");
            Console.WriteLine("  --superops          Enable super operators (default: on)");
            Console.WriteLine("  --no-superops       Disable super operators");
            Console.WriteLine("  --compress          Enable bytecode LZW compression (default: on)");
            Console.WriteLine("  --no-compress       Disable bytecode compression");
            Console.WriteLine("  --encrypt-strings   Encrypt all string constants");
            Console.WriteLine("  --max-mutations N   Max mutations to generate (default: 300)");
            Console.WriteLine("  --max-mega N        Max mega super operators (default: 200)");
            Console.WriteLine("  --max-mini N        Max mini super operators (default: 150)");
            Console.WriteLine("  --help              Show this help");
        }

        static int Main(string[] args)
        {
            if (args.Length == 0 || args.Contains("--help") || args.Contains("-h"))
            {
                PrintHelp();
                return 0;
            }

            // Parse args
            string inputFile = null;
            string outputFile = null;
            string luacPath = "luac5.1.exe";
            bool mutate = true;
            bool superOps = true;
            bool compress = true;
            bool encryptStrings = false;
            int maxMutations = 300;
            int maxMega = 200;
            int maxMini = 150;

            for (int i = 0; i < args.Length; i++)
            {
                switch (args[i])
                {
                    case "--luac":       luacPath = args[++i]; break;
                    case "--mutate":     mutate = true; break;
                    case "--no-mutate":  mutate = false; break;
                    case "--superops":   superOps = true; break;
                    case "--no-superops": superOps = false; break;
                    case "--compress":   compress = true; break;
                    case "--no-compress": compress = false; break;
                    case "--encrypt-strings": encryptStrings = true; break;
                    case "--max-mutations": maxMutations = int.Parse(args[++i]); break;
                    case "--max-mega":   maxMega = int.Parse(args[++i]); break;
                    case "--max-mini":   maxMini = int.Parse(args[++i]); break;
                    default:
                        if (inputFile == null) inputFile = args[i];
                        else if (outputFile == null) outputFile = args[i];
                        break;
                }
            }

            if (inputFile == null)
            {
                Console.Error.WriteLine("Error: No input file specified.");
                return 1;
            }

            if (!File.Exists(inputFile))
            {
                Console.Error.WriteLine($"Error: Input file not found: {inputFile}");
                return 1;
            }

            if (outputFile == null)
                outputFile = Path.ChangeExtension(inputFile, ".ib2.lua");

            // Find luac - check same dir as exe first
            string exeDir = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule?.FileName ?? ".");
            if (!File.Exists(luacPath))
            {
                string candidate = Path.Combine(exeDir, luacPath);
                if (File.Exists(candidate)) luacPath = candidate;
            }

            if (!File.Exists(luacPath))
            {
                Console.Error.WriteLine($"Error: luac not found at '{luacPath}'. Use --luac <path> to specify.");
                return 1;
            }

            Console.WriteLine($"[IronBrew2] Input:    {inputFile}");
            Console.WriteLine($"[IronBrew2] Output:   {outputFile}");
            Console.WriteLine($"[IronBrew2] Mutate:   {mutate}  SuperOps: {superOps}  Compress: {compress}");

            try
            {
                // Step 1: Compile with luac5.1
                string tmpBytecode = Path.GetTempFileName();
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = luacPath,
                        Arguments = $"-o \"{tmpBytecode}\" \"{inputFile}\"",
                        RedirectStandardError = true,
                        UseShellExecute = false
                    };

                    var proc = Process.Start(psi);
                    string luacErr = proc.StandardError.ReadToEnd();
                    proc.WaitForExit();

                    if (proc.ExitCode != 0)
                    {
                        Console.Error.WriteLine($"[luac error] {luacErr}");
                        return 1;
                    }

                    Console.WriteLine($"[IronBrew2] Compiled to bytecode OK");

                    // Step 2: Deserialize bytecode
                    byte[] bytecodeBytes = File.ReadAllBytes(tmpBytecode);
                    var deserializer = new Deserializer(bytecodeBytes);
                    Chunk headChunk = deserializer.DecodeFile();

                    Console.WriteLine($"[IronBrew2] Deserialized bytecode OK");

                    // Step 3: Build obfuscation context + settings
                    var context = new ObfuscationContext(headChunk);
                    var settings = new ObfuscationSettings
                    {
                        Mutate = mutate,
                        SuperOperators = superOps,
                        BytecodeCompress = compress,
                        EncryptStrings = false,          // We do string encrypt via ConstantEncryption post-gen
                        EncryptImportantStrings = false,
                        MaxMutations = maxMutations,
                        MaxMegaSuperOperators = maxMega,
                        MaxMiniSuperOperators = maxMini,
                        PreserveLineInfo = false,
                        ControlFlow = false,             // CF is applied at source level separately
                    };

                    // Step 4: Generate VM
                    var generator = new Generator(context);
                    string vm = generator.GenerateVM(settings);

                    Console.WriteLine($"[IronBrew2] VM generated OK");

                    // Step 5: Optional string encryption pass on the VM source
                    if (encryptStrings)
                    {
                        var enc = new ConstantEncryption(settings, vm);
                        vm = enc.EncryptStrings();
                        Console.WriteLine($"[IronBrew2] String encryption applied");
                    }

                    // Step 6: Write output
                    File.WriteAllText(outputFile, vm);
                    Console.WriteLine($"[IronBrew2] Done! Output: {outputFile} ({new FileInfo(outputFile).Length} bytes)");
                    return 0;
                }
                finally
                {
                    if (File.Exists(tmpBytecode))
                        File.Delete(tmpBytecode);
                }
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[IronBrew2] Fatal error: {ex.Message}");
                Console.Error.WriteLine(ex.StackTrace);
                return 1;
            }
        }
    }
}
