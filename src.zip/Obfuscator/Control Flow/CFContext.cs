using System;
using System.Collections.Generic;
using System.Linq;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;
using IronBrew2.Obfuscator.Control_Flow.Types;

namespace IronBrew2.Obfuscator.Control_Flow
{
	public class CFContext
	{
		public Chunk lChunk;

		// Neutralises a marker instruction pair (GetGlobal + Call) by replacing both with no-op Moves
		private static void NullifyMarker(Instruction instr, Instruction call)
		{
			instr.OpCode = Opcode.Move; instr.A = 0; instr.B = 0;
			call.OpCode  = Opcode.Move; call.A  = 0; call.B  = 0;
		}

		// Slices the current live instruction range between CBegin and the current marker instruction.
		// Must be called fresh each time because passes mutate the instruction list in-place.
		private static List<Instruction> SliceRegion(Chunk c, Instruction cBegin, Instruction cEnd)
		{
			int start = c.InstructionMap[cBegin];
			int end   = c.InstructionMap[cEnd];
			return c.Instructions.Skip(start).Take(end - start).ToList();
		}

		public void DoChunk(Chunk c)
		{
			bool chunkHasCflow = false;
			Instruction cBegin = null;

			var instructs = c.Instructions.ToList();
			for (int index = 0; index < instructs.Count - 1; index++)
			{
				Instruction instr = instructs[index];
				if (instr.OpCode != Opcode.GetGlobal || instructs[index + 1].OpCode != Opcode.Call)
					continue;

				string str = ((Constant) instr.RefOperands[0]).Data.ToString();

				switch (str)
				{
					case "IB_MAX_CFLOW_START":
						cBegin        = instr;
						chunkHasCflow = true;
						NullifyMarker(instr, instructs[index + 1]);
						break;

					case "IB_MAX_CFLOW_END":
					{
						NullifyMarker(instr, instructs[index + 1]);

						// Each pass can shift instruction indices — re-slice before every pass
						TestSpam.DoInstructions(c, SliceRegion(c, cBegin, instr));
						Bounce.DoInstructions(c, SliceRegion(c, cBegin, instr));
						TestPreserve.DoInstructions(c, SliceRegion(c, cBegin, instr));
						EQMutate.DoInstructions(c, c.Instructions.ToList());
						break;
					}
				}
			}

			TestFlip.DoInstructions(c, c.Instructions.ToList());

			if (chunkHasCflow)
				c.Instructions.Insert(0, new Instruction(c, Opcode.NewStack));

			foreach (Chunk child in c.Functions)
				DoChunk(child);
		}

		public void DoChunks()
		{
			new Inlining(lChunk).DoChunks();
			DoChunk(lChunk);
		}

		public CFContext(Chunk lChunk_) =>
			lChunk = lChunk_;
	}
}
