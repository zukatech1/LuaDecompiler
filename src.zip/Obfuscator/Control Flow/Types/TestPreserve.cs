using System;
using System.Collections.Generic;
using System.Linq;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;
using IronBrew2.Extensions;

namespace IronBrew2.Obfuscator.Control_Flow.Types
{
	public static class TestPreserve
	{
		// NOTE: 'used' was previously a static field, causing bleed across recursive DoChunk calls.
		// It is now a local variable passed into NIntND so each DoInstructions call is fully isolated.
		private static int NIntND(int min, int max, List<int> used)
		{
			var x = Enumerable.Range(min, max - min).ToList();
			x.RemoveAll(y => used.Contains(y));
			x.Shuffle();
			int n = x[0];
			used.Add(n);
			return n;
		}

		public static void DoInstructions(Chunk chunk, List<Instruction> instructions)
		{
			for (int idx = 0; idx < instructions.Count; idx++)
			{
				// Fresh 'used' list per instruction — no cross-instruction bleed
				var used = new List<int>();

				Instruction i = instructions[idx];
				switch (i.OpCode)
				{
					case Opcode.Lt:
					case Opcode.Le:
					case Opcode.Eq:
					{
						int mReg1 = 250;
						int mReg2 = 251;

						Instruction ma, mb;

						if (i.RefOperands[0] is Constant c1)
						{
							ma   = new Instruction(chunk, Opcode.LoadConst, c1);
							ma.A = mReg1;
						}
						else
						{
							ma   = new Instruction(chunk, Opcode.Move);
							ma.A = mReg1;
							ma.B = i.B;
						}

						if (i.RefOperands[1] is Constant c2)
						{
							mb   = new Instruction(chunk, Opcode.LoadConst, c2);
							mb.A = mReg2;
						}
						else
						{
							mb   = new Instruction(chunk, Opcode.Move);
							mb.A = mReg2;
							mb.B = i.C;
						}

						Instruction loadbool1 = new Instruction(chunk, Opcode.LoadBool) { A = mReg1, B = 0 };
						Instruction loadbool2 = new Instruction(chunk, Opcode.LoadBool) { A = mReg2, B = 0 };

						i.B = mReg1;
						i.C = mReg2;
						i.SetupRefs();

						chunk.Instructions.InsertRange(chunk.InstructionMap[i] + 2, new[] { new Instruction(loadbool1), new Instruction(loadbool2) });
						chunk.Instructions.InsertRange(chunk.InstructionMap[i],     new[] { ma, mb });
						chunk.UpdateMappings();

						chunk.Instructions.InsertRange(
							chunk.InstructionMap[(Instruction) chunk.Instructions[chunk.InstructionMap[i] + 1].RefOperands[0]],
							new[] { loadbool1, loadbool2 });

						chunk.Instructions[chunk.InstructionMap[i] + 1].RefOperands[0] = loadbool1;
						chunk.UpdateMappings();

						foreach (Instruction ins in i.BackReferences)
							ins.RefOperands[0] = ma;

						break;
					}

					case Opcode.Test:
					case Opcode.TestSet:
					{
						int rReg = NIntND(0,   128, used);
						int pReg = NIntND(257, 512, used);

						Instruction m1 = new Instruction(chunk, Opcode.Move) { A = pReg, B = rReg };
						Instruction m2 = new Instruction(chunk, Opcode.Move) { A = rReg, B = i.A  };
						Instruction lb = new Instruction(chunk, Opcode.LoadBool) { A = pReg, B = 0 };
						Instruction m3 = new Instruction(chunk, Opcode.Move) { A = rReg, B = pReg };

						chunk.Instructions.InsertRange(chunk.InstructionMap[i] + 2, new[] { new Instruction(m3), new Instruction(lb) });
						chunk.Instructions.InsertRange(chunk.InstructionMap[i],     new[] { m1, m2 });
						chunk.UpdateMappings();

						chunk.Instructions.InsertRange(
							chunk.InstructionMap[(Instruction) chunk.Instructions[chunk.InstructionMap[i] + 1].RefOperands[0]],
							new[] { m3, lb });

						chunk.Instructions[chunk.InstructionMap[i] + 1].RefOperands[0] = m3;
						chunk.UpdateMappings();

						foreach (Instruction ins in i.BackReferences)
							ins.RefOperands[0] = m1;

						break;
					}
				}
			}
		}
	}
}
