using System;
using System.Collections.Generic;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;

namespace IronBrew2.Obfuscator.Control_Flow.Types
{
	// NumberMutate — replaces LoadK number constants with a runtime XOR expression.
	//
	// For every LoadK instruction that loads a number constant, the stored constant
	// is replaced with (original XOR key), and a runtime XOR is emitted to recover
	// the original value before use.  This defeats static constant extraction tools
	// that simply dump the constant table.
	//
	// Before:  LOADK R[a]  <-- 42.0
	// After:   LOADK R[tmp] <-- (42 XOR key)
	//          XOR   R[a], R[tmp], key       (emulated via arithmetic in the VM)
	//
	// Note: Lua numbers are doubles, so XOR is simulated via integer truncation.
	// Only integers representable exactly as doubles are mutated to avoid precision loss.
	public static class NumberMutate
	{
		private static readonly Random Rand = new Random();

		// Returns true if d can be round-tripped through int32 XOR without loss
		private static bool IsSafeInteger(double d) =>
			d == Math.Truncate(d) && d >= int.MinValue && d <= int.MaxValue;

		public static void DoInstructions(Chunk chunk)
		{
			// Work on a snapshot — we insert instructions as we go
			var instructions = new List<Instruction>(chunk.Instructions);

			foreach (Instruction instr in instructions)
			{
				if (instr.OpCode != Opcode.LoadConst) continue;
				if (instr.RefOperands[0] is not Constant c) continue;
				if (c.Type != ConstantType.Number)         continue;

				double original = (double) c.Data;
				if (!IsSafeInteger(original)) continue;

				int key        = Rand.Next(1, 0x7FFF); // non-zero key
				int mutated    = (int) original ^ key;

				// Replace the constant value with the XOR'd version
				Constant mutatedConst = new Constant
				{
					Type = ConstantType.Number,
					Data = (double) mutated
				};

				// Add mutated constant if not already present
				if (!chunk.ConstantMap.ContainsKey(mutatedConst))
				{
					chunk.Constants.Add(mutatedConst);
					chunk.ConstantMap[mutatedConst] = chunk.Constants.Count - 1;
				}

				// Add XOR key constant
				Constant keyConst = new Constant
				{
					Type = ConstantType.Number,
					Data = (double) key
				};
				if (!chunk.ConstantMap.ContainsKey(keyConst))
				{
					chunk.Constants.Add(keyConst);
					chunk.ConstantMap[keyConst] = chunk.Constants.Count - 1;
				}

				// Repoint the LoadK to the mutated constant
				instr.RefOperands[0] = mutatedConst;

				// Insert a LoadK + BXor pair immediately after to recover the original value.
				// The VM must support a BXor opcode; if your VM uses arithmetic XOR emulation,
				// replace Opcode.BXor with whatever your VM uses for integer XOR.
				int idx = chunk.InstructionMap[instr];

				Instruction loadKey = new Instruction(chunk, Opcode.LoadConst, keyConst)
				{
					A = instr.A + 1   // temp register
				};

				// Placeholder: emit a Move that the serializer will translate to the XOR
				// pattern. Replace with your VM's actual XOR opcode if available.
				Instruction xorInstr = new Instruction(chunk, Opcode.Move)
				{
					A = instr.A,      // destination: same register
					B = instr.A,      // lhs: mutated value
					// C would be instr.A + 1 for key — set after insertion
				};
				xorInstr.C = instr.A + 1;

				chunk.Instructions.InsertRange(idx + 1, new[] { loadKey, xorInstr });
				chunk.UpdateMappings();
			}

			foreach (Chunk child in chunk.Functions)
				DoInstructions(child);
		}
	}
}
