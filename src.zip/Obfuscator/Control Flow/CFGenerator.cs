using System;
using System.Linq;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;

namespace IronBrew2.Obfuscator.Control_Flow
{
	public class CFGenerator
	{
		public Random Random = new Random();

		// Opcodes that are safe to use as junk instructions (no flow/ref side effects)
		private static readonly Opcode[] SafeJunkOpcodes =
		{
			Opcode.Move, Opcode.LoadNil, Opcode.LoadBool,
			Opcode.Unm,  Opcode.Not,     Opcode.Len,
			Opcode.Concat,
		};

		public Instruction NextJMP(Chunk lc, Instruction reference) =>
			new Instruction(lc, Opcode.Jmp, reference);

		// Produces a believable-looking random instruction that won't corrupt control flow.
		// Previously used a while(true) retry loop over a blacklist — replaced with a direct
		// whitelist pick so termination is always guaranteed in O(1).
		public Instruction BelievableRandom(Chunk lc)
		{
			Instruction ins = new Instruction(lc, SafeJunkOpcodes[Random.Next(SafeJunkOpcodes.Length)]);
			ins.A = Random.Next(0, 128);
			ins.B = Random.Next(0, 128);
			ins.C = Random.Next(0, 128);
			return ins;
		}

		public Constant GetOrAddConstant(Chunk chunk, ConstantType type, dynamic constant, out int constantIndex)
		{
			var current = chunk.Constants.FirstOrDefault(c => c.Type == type && c.Data == constant);
			if (current != null)
			{
				constantIndex = chunk.Constants.IndexOf(current);
				return current;
			}

			Constant newConst = new Constant { Type = type, Data = constant };

			constantIndex = chunk.Constants.Count;
			chunk.Constants.Add(newConst);
			chunk.ConstantMap.Add(newConst, constantIndex);

			return newConst;
		}
	}
}
