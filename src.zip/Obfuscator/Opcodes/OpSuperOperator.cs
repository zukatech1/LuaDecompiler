using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using IronBrew2.Bytecode_Library.IR;

namespace IronBrew2.Obfuscator.Opcodes
{
	public class OpSuperOperator : VOpcode
	{
		public VOpcode[] SubOpcodes;

		public override bool IsInstruction(Instruction instruction) =>
			false;

		public bool IsInstruction(List<Instruction> instructions)
		{
			if (instructions.Count != SubOpcodes.Length)
				return false;

			for (int i = 0; i < SubOpcodes.Length; i++)
			{
				if (SubOpcodes[i] is OpMutated mut)
				{
					if (!mut.Mutated.IsInstruction(instructions[i]))
						return false;
				}
				else if (!SubOpcodes[i].IsInstruction(instructions[i]))
					return false;
			}

			return true;
		}

		// Mirrors Generator.OpcodeRawToToken — kept in sync manually.
		// Translates raw opcode handler names to their VMStrings token equivalents
		// so the same random name is used in both the VM frame and handler bodies.
		private static readonly (string Raw, string Token)[] RawToToken =
		{
			("InstrPoint", "VM_IP"),
			("Upvalues",   "WR_UPVALS"),
			("Varargsz",   "VM_VSZ"),
			("Lupvals",    "VM_UPV"),
			("Vararg",     "VM_VARG"),
			("Params",     "WR_PARAMS"),
			("PCount",     "VM_PC"),
			("Unpack",     "GB_UNPACK"),
			("Instr",      "WR_INSTR"),
			("Const",      "WR_CONST"),
			("Proto",      "WR_PROTO"),
			("Wrap",       "WR_WRAP"),
			("Inst",       "VM_INST"),
			("Enum",       "VM_ENUM"),
			("Env",        "WR_ENV"),
			("Stk",        "VM_STK"),
			("Top",        "VM_TOP"),
			("_R",         "DC_R"),
		};

		private static string PreTranslate(string s)
		{
			// Word-boundary matching prevents partial-word corruption:
			// "Stk" must not match inside "NStk", "_R" must not hit "DC_R", etc.
			foreach (var (raw, token) in RawToToken)
				s = System.Text.RegularExpressions.Regex.Replace(
					s, @"\b" + System.Text.RegularExpressions.Regex.Escape(raw) + @"\b", token);
			return s;
		}

		private static string ApplyMap(string s, Dictionary<string, string> map)
		{
			foreach (var kv in map.OrderByDescending(kv => kv.Key.Length))
				s = s.Replace(kv.Key, kv.Value);
			return s;
		}

		public override string GetObfuscated(ObfuscationContext context)
		{
			// Step 1: build the combined handler string with hoisted locals.
			// Local hoisting regex runs on raw names BEFORE any translation,
			// since the regex pattern matches known raw identifiers.
			var    localRegex = new Regex(@"local(.*?)[;=]");
			var    hoisted    = new List<string>();
			string combined   = "";
			string instrAdv   = "InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];";

			for (int index = 0; index < SubOpcodes.Length; index++)
			{
				string s2 = SubOpcodes[index].GetObfuscated(context);

				foreach (Match m in localRegex.Matches(s2))
				{
					string loc = m.Groups[1].Value.Replace(" ", "");
					if (!hoisted.Contains(loc))
						hoisted.Add(loc);

					s2 = m.Value.Contains(";")
						? s2.Replace($"local{m.Groups[1].Value};", "")
						: s2.Replace($"local{m.Groups[1].Value}", loc);
				}

				combined += s2;

				if (index + 1 < SubOpcodes.Length)
					combined += instrAdv;
			}

			foreach (string l in hoisted)
				combined = "local " + l + ";" + combined;

			// Step 2: pre-translate raw opcode names → VM token equivalents
			combined = PreTranslate(combined);

			// Step 3: apply the name map so all tokens become random identifiers
			if (context.NameMap != null && context.NameMap.Count > 0)
				combined = ApplyMap(combined, context.NameMap);

			return combined;
		}
	}
}
