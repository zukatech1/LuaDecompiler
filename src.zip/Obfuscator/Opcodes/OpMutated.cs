using System;
using System.Text.RegularExpressions;
using IronBrew2.Bytecode_Library.IR;

namespace IronBrew2.Obfuscator.Opcodes
{
	// OpMutated wraps a base VOpcode and re-emits its Lua handler with the
	// OP_A / OP_B / OP_C slot indices permuted according to the Registers array.
	//
	// Previously GetObfuscated just forwarded to Mutated.GetObfuscated — the
	// Registers field existed but was never applied, so all mutated handlers
	// produced identical Lua to their base opcode. An analyser reading the
	// dispatch tree could trivially see through them.
	//
	// Now: Registers = {r0, r1, r2} describes where A, B, C land in the
	// serialized instruction word. The VM reads operands from slots
	// [OP_ENUM=1, OP_A=2, OP_B=3, OP_BX=4, OP_C=5, OP_DATA=6].
	// We permute slots 2,3,5 (A, B, C) according to Registers, then emit
	// substituted accessor strings — so the Lua code reads from different
	// physical positions while the serializer writes to those same positions.
	//
	// Result: handlers for the same logical opcode look structurally different
	// in the dispatch tree, breaking pattern-matching across mutations.
	public class OpMutated : VOpcode
	{
		public static Random rand = new Random();

		public VOpcode Mutated;

		// Registers[0..2] is a permutation of {0,1,2} describing how the
		// physical instruction word slots map to logical A, B, C operands.
		public int[] Registers;

		public override bool IsInstruction(Instruction instruction) => false;

		public bool CheckInstruction() => rand.Next(1, 15) == 1;

		public override string GetObfuscated(ObfuscationContext context)
		{
			string baseCode = Mutated.GetObfuscated(context);

			if (Registers == null || Registers.Length < 3)
				return baseCode;

			// The three logical-to-physical slot mappings.
			// Logical A reads from physical slot physA, etc.
			// Slot numbers in the instruction table: A=2, B=3, C=5
			int[] physicalSlots = { 2, 3, 5 };  // OP_A, OP_B, OP_C

			int physA = physicalSlots[Registers[0]];
			int physB = physicalSlots[Registers[1]];
			int physC = physicalSlots[Registers[2]];

			// Replace OP_A/OP_B/OP_C token placeholders with their permuted slot numbers.
			// We do this BEFORE the final OP_X → integer substitution in Generator.cs,
			// so the output still uses the OP_ prefix here and gets resolved later.
			//
			// Strategy: rename to temp tokens first to avoid double-substitution,
			// e.g. if A→B and B→A, replacing OP_A→OP_B then OP_B→OP_A would undo itself.
			string result = baseCode
				.Replace("OP_A",  "##PA##")
				.Replace("OP_B",  "##PB##")
				.Replace("OP_C",  "##PC##");

			// Now resolve temps to the permuted physical slot tokens.
			// We emit raw slot numbers rather than OP_ names so the Generator's
			// final .Replace("OP_A","2") pass doesn't clobber our permutation.
			result = result
				.Replace("##PA##", physA.ToString())
				.Replace("##PB##", physB.ToString())
				.Replace("##PC##", physC.ToString());

			return result;
		}

		public override void Mutate(Instruction instruction)
		{
			// Apply the base opcode's field mutation first
			Mutated.Mutate(instruction);

			// Then reorder A/B/C in the instruction according to our permutation,
			// so the serializer writes operands to the slots our handler reads from.
			if (Registers == null || Registers.Length < 3) return;

			int origA = instruction.A;
			int origB = instruction.B;
			int origC = instruction.C;

			int[] src = { origA, origB, origC };

			// Registers[i] = j means logical slot i gets its value from original slot j
			instruction.A = src[Registers[0]];
			instruction.B = src[Registers[1]];
			instruction.C = src[Registers[2]];
		}
	}
}
