using System;
using System.Collections.Generic;
using System.Linq;
using IronBrew2.Bytecode_Library.Bytecode;
using IronBrew2.Bytecode_Library.IR;
using IronBrew2.Extensions;

namespace IronBrew2.Obfuscator
{
	public enum ChunkStep
	{
		ParameterCount,
		StringTable,
		Instructions,
		Constants,
		Functions,
		LineInfo,
		StepCount
	}

	public enum InstructionStep1
	{
		Type,
		A,
		B,
		C,
		StepCount
	}

	public enum InstructionStep2
	{
		Op,
		Bx,
		D,
		StepCount
	}
	
	public class ObfuscationContext
	{
		public Chunk HeadChunk;
		public ChunkStep[] ChunkSteps;
		public InstructionStep1[] InstructionSteps1;
		public InstructionStep2[] InstructionSteps2;
		public int[] ConstantMapping;

		public Dictionary<Opcode, VOpcode> InstructionMapping = new Dictionary<Opcode, VOpcode>();

		// Populated by Generator.BuildNameMap() before VM generation.
		// Passed into GetObfuscated() via context so opcode handler strings
		// get their identifiers randomised along with everything else.
		public Dictionary<string, string> NameMap = new Dictionary<string, string>();

		public int PrimaryXorKey;
		public int IXorKey1;
		public int IXorKey2;

		// rand.Next(min, max) requires max > min strictly, so the safe ceiling for
		// rand.Next(1, maxVal + 1) is maxVal <= int.MaxValue - 1.
		// Previously used 0x7FFFFFFF (== int.MaxValue) which caused maxVal + 1 to
		// overflow to int.MinValue, making minValue > maxValue and crashing.
		private static int NonZeroRand(Random rand)
		{
			// Range [1, int.MaxValue) — full positive int range, guaranteed non-zero
			return rand.Next(1, int.MaxValue);
		}

		public ObfuscationContext(Chunk chunk)
		{
			HeadChunk = chunk;

			ChunkSteps = Enumerable.Range(0, (int) ChunkStep.StepCount).Select(i => (ChunkStep) i).ToArray();
			ChunkSteps.Shuffle();
			
			InstructionSteps1 = Enumerable.Range(0, (int) InstructionStep1.StepCount).Select(i => (InstructionStep1) i).ToArray();
			InstructionSteps1.Shuffle();
			
			InstructionSteps2 = Enumerable.Range(0, (int) InstructionStep2.StepCount).Select(i => (InstructionStep2) i).ToArray();
			InstructionSteps2.Shuffle();
			
			ConstantMapping = Enumerable.Range(0, 4).ToArray();
			ConstantMapping.Shuffle();

			Random rand = new Random();

			// Widened to 32 bits, never zero — XOR always has effect
			PrimaryXorKey = NonZeroRand(rand);
			IXorKey1      = NonZeroRand(rand);
			IXorKey2      = NonZeroRand(rand);
		}
	}
}
