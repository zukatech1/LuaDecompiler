namespace IronBrew2.Obfuscator
{
	public class ObfuscationSettings
	{
		private int _decryptTableLen = 500;
		private int _maxMutations    = 300;
		private int _maxMiniSuperOps = 150;
		private int _maxMegaSuperOps = 200;

		public bool EncryptStrings          { get; set; }
		public bool EncryptImportantStrings { get; set; }
		public bool ControlFlow             { get; set; }
		public bool BytecodeCompress        { get; set; }
		public bool PreserveLineInfo        { get; set; }
		public bool Mutate                  { get; set; }
		public bool SuperOperators          { get; set; }

		public int DecryptTableLen
		{
			get => _decryptTableLen;
			set => _decryptTableLen = value > 0 ? value : 1;
		}

		public int MaxMutations
		{
			get => _maxMutations;
			set => _maxMutations = value >= 0 ? value : 0;
		}

		public int MaxMiniSuperOperators
		{
			get => _maxMiniSuperOps;
			set => _maxMiniSuperOps = value >= 0 ? value : 0;
		}

		public int MaxMegaSuperOperators
		{
			get => _maxMegaSuperOps;
			set => _maxMegaSuperOps = value >= 0 ? value : 0;
		}

		public ObfuscationSettings()
		{
			EncryptStrings          = false;
			EncryptImportantStrings = false;
			ControlFlow             = true;
			BytecodeCompress        = true;
			PreserveLineInfo        = false;
			Mutate                  = true;
			SuperOperators          = true;
		}

		// Fluent builder helpers
		public ObfuscationSettings WithEncryptStrings(bool v)          { EncryptStrings          = v; return this; }
		public ObfuscationSettings WithEncryptImportantStrings(bool v) { EncryptImportantStrings = v; return this; }
		public ObfuscationSettings WithControlFlow(bool v)             { ControlFlow             = v; return this; }
		public ObfuscationSettings WithBytecodeCompress(bool v)        { BytecodeCompress        = v; return this; }
		public ObfuscationSettings WithPreserveLineInfo(bool v)        { PreserveLineInfo        = v; return this; }
		public ObfuscationSettings WithMutate(bool v)                  { Mutate                  = v; return this; }
		public ObfuscationSettings WithSuperOperators(bool v)          { SuperOperators          = v; return this; }
		public ObfuscationSettings WithMaxMutations(int v)             { MaxMutations            = v; return this; }
		public ObfuscationSettings WithDecryptTableLen(int v)          { DecryptTableLen         = v; return this; }
		public ObfuscationSettings WithMaxMiniSuperOperators(int v)    { MaxMiniSuperOperators   = v; return this; }
		public ObfuscationSettings WithMaxMegaSuperOperators(int v)    { MaxMegaSuperOperators   = v; return this; }
	}
}
