using System;
using System.Collections.Generic;
using System.Text;

namespace IronBrew2.Obfuscator.Encryption
{
	// VMIntegrityCheck — embeds a checksum of the serialized bytecode into the VM
	// header and emits a Lua snippet that verifies it at runtime before execution.
	//
	// If the bytecode is patched (e.g. to remove an anti-cheat call or skip a check),
	// the checksum fails and the VM halts before executing a single instruction.
	//
	// Algorithm: Adler-32 — simple, fast, no external dependencies, good distribution.
	// The key is XOR'd into the checksum so it differs across obfuscation runs even
	// for identical input, making static signature matching harder.
	public class VMIntegrityCheck
	{
		private readonly int _xorKey;

		public VMIntegrityCheck(int xorKey) =>
			_xorKey = xorKey;

		// Adler-32 over the serialized bytecode, then XOR with the session key
		public static uint ComputeChecksum(byte[] data, int xorKey)
		{
			const uint MOD = 65521;
			uint a = 1, b = 0;

			foreach (byte bt in data)
			{
				a = (a + bt)  % MOD;
				b = (b + a)   % MOD;
			}

			uint adler = (b << 16) | a;
			return adler ^ (uint) xorKey;
		}

		// Returns a Lua snippet that must be prepended to the VM string.
		// It verifies the checksum of ByteString before the deserializer runs.
		// On failure it wipes ByteString and errors — execution cannot continue.
		public string GenerateCheckSnippet(byte[] serializedBytecode)
		{
			uint expected = ComputeChecksum(serializedBytecode, _xorKey);

			// Inline Adler-32 + XOR in Lua — no external libs, Lua 5.1 compatible
			return $@"
local function __ibchk(s,k)
  local a,b,MOD=1,0,65521
  for i=1,#s do
    local v=string.byte(s,i)
    a=(a+v)%MOD; b=(b+a)%MOD
  end
  local h=((b*65536)+a)
  -- manual XOR: Lua 5.1 has no bit library
  local r,d=0,1
  local x,y=h,k
  while x>0 or y>0 do
    local xb,yb=x%2,y%2
    if xb~=yb then r=r+d end
    x,y,d=math.floor(x/2),math.floor(y/2),d*2
  end
  return r
end
if __ibchk(ByteString,{_xorKey}) ~= {expected} then
  ByteString=nil
  error(""[IronBrew] Integrity check failed."",0)
end
";
		}
	}
}
