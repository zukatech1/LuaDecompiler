using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace IronBrew2.Obfuscator.Encryption
{
	// RC4 stream cipher — replaces the previous repeating-key XOR.
	//
	// Why the old approach was broken:
	//   repeating-key XOR with key length L means plaintext[i] ^ key[i % L].
	//   If an attacker knows (or guesses) any plaintext byte, they immediately
	//   recover key[i % L] and can decrypt every byte at that key position.
	//   For Lua strings this is trivial — globals like "print", "pairs", "pcall"
	//   appear constantly and give known-plaintext for free.
	//
	// RC4 fixes this: the keystream is stateful and non-repeating for the
	// duration of the message, so knowing one plaintext byte reveals only
	// one keystream byte with no periodicity to exploit.
	//
	// Each Decryptor instance generates a fresh random key, so every string
	// (or batch of strings) gets an independent keystream.
	public static class RC4
	{
		public static byte[] Encrypt(byte[] data, byte[] key)
		{
			// Key-scheduling algorithm (KSA)
			byte[] S = new byte[256];
			for (int i = 0; i < 256; i++) S[i] = (byte)i;

			int j = 0;
			for (int i = 0; i < 256; i++)
			{
				j = (j + S[i] + key[i % key.Length]) & 0xFF;
				(S[i], S[j]) = (S[j], S[i]);
			}

			// Pseudo-random generation algorithm (PRGA)
			byte[] output = new byte[data.Length];
			int x = 0, y = 0;
			for (int i = 0; i < data.Length; i++)
			{
				x = (x + 1) & 0xFF;
				y = (y + S[x]) & 0xFF;
				(S[x], S[y]) = (S[y], S[x]);
				output[i] = (byte)(data[i] ^ S[(S[x] + S[y]) & 0xFF]);
			}

			return output;
		}

		// Emits a Lua 5.1-compatible RC4 decryption function and the call that
		// decrypts the ciphertext back to the original string at runtime.
		// The key and ciphertext are embedded as Lua \NNN escape sequences.
		public static string EmitLuaDecrypt(byte[] ciphertext, byte[] key)
		{
			string keyStr    = string.Join("", key.Select(b => "\\" + b));
			string cipherStr = string.Join("", ciphertext.Select(b => "\\" + b));

			// Inline RC4 in Lua — no external libraries, Lua 5.1 compatible.
			// The decryptor is inlined per call so it's harder to centralise and hook.
			return
				$"(function()\n" +
				$"  local k=\"{keyStr}\"\n" +
				$"  local c=\"{cipherStr}\"\n" +
				$"  local S={{}} for i=0,255 do S[i]=i end\n" +
				$"  local j=0\n" +
				$"  for i=0,255 do\n" +
				$"    j=(j+S[i]+string.byte(k,i%#k+1))%256\n" +
				$"    S[i],S[j]=S[j],S[i]\n" +
				$"  end\n" +
				$"  local x,y,out=0,0,{{}}\n" +
				$"  for i=1,#c do\n" +
				$"    x=(x+1)%256\n" +
				$"    y=(y+S[x])%256\n" +
				$"    S[x],S[y]=S[y],S[x]\n" +
				$"    out[i]=string.char(string.byte(c,i)~S[(S[x]+S[y])%256])\n" +  // ~ is XOR in Lua 5.3+; see note below
				$"  end\n" +
				$"  return table.concat(out)\n" +
				$"end)()";
			// NOTE: ~ for XOR requires Lua 5.3+. For Lua 5.1 targets (Roblox etc.)
			// replace with the BitXOR helper that's already emitted in VMP1.
			// The caller (ConstantEncryption) substitutes the right XOR call below.
		}

		// Lua 5.1-safe version — uses the BitXOR function already present in the VM header.
		// This is what we actually emit so it works on all targets including Roblox.
		public static string EmitLuaDecryptLua51(byte[] ciphertext, byte[] key, string xorFn = "BitXOR")
		{
			string keyStr    = string.Join("", key.Select(b => "\\" + b));
			string cipherStr = string.Join("", ciphertext.Select(b => "\\" + b));

			return
				$"(function()\n" +
				$"local k=\"{keyStr}\"\n" +
				$"local c=\"{cipherStr}\"\n" +
				$"local S={{}} for i=0,255 do S[i]=i end\n" +
				$"local j=0\n" +
				$"for i=0,255 do\n" +
				$"  j=(j+S[i]+string.byte(k,i%#k+1))%256\n" +
				$"  S[i],S[j]=S[j],S[i]\n" +
				$"end\n" +
				$"local x,y,out=0,0,{{}}\n" +
				$"for i=1,#c do\n" +
				$"  x=(x+1)%256 y=(y+S[x])%256\n" +
				$"  S[x],S[y]=S[y],S[x]\n" +
				$"  out[i]=string.char({xorFn}(string.byte(c,i),S[(S[x]+S[y])%256]))\n" +
				$"end\n" +
				$"return table.concat(out)\n" +
				$"end)()";
		}
	}

	public class Decryptor
	{
		public byte[] Key;
		public string Name;

		// Encrypt bytes with RC4 and return the Lua snippet that decrypts at runtime.
		public string Encrypt(byte[] plaintext)
		{
			byte[] cipher = RC4.Encrypt(plaintext, Key);
			return RC4.EmitLuaDecryptLua51(cipher, Key);
		}

		public Decryptor(string name, int keyLen)
		{
			Random r = new Random();
			Name = name;
			// Key length: clamp to [8, 32] — short enough to not bloat output,
			// long enough that brute force is not viable
			int safeLen = Math.Max(8, Math.Min(keyLen, 32));
			Key = new byte[safeLen];
			r.NextBytes(Key);
			// Ensure no zero bytes in key — RC4 is technically fine with them but
			// Lua string literals with \0 can cause issues in some environments
			for (int i = 0; i < Key.Length; i++)
				if (Key[i] == 0) Key[i] = (byte)r.Next(1, 256);
		}
	}

	public class ConstantEncryption
	{
		private string              _src;
		private ObfuscationSettings _settings;
		private readonly Encoding   _luaEncoding = Encoding.GetEncoding(28591);

		// Compiled once — reused across all branches
		private static readonly Regex EncRegex = new Regex(
			@"(['""])?(?(1)((?:[^\\]|\\.)*?)\1|\[(=*)\[(.*?)\]\3\])",
			RegexOptions.Singleline | RegexOptions.Compiled);

		public Decryptor GenerateGenericDecryptor(MatchCollection matches)
		{
			int len = 0;
			for (int i = 0; i < matches.Count; i++)
			{
				int l = matches[i].Length;
				if (l > len) len = l;
			}
			// Key length scales with content but is clamped inside Decryptor
			if (len > _settings.DecryptTableLen) len = _settings.DecryptTableLen;
			return new Decryptor("IRONBREW_STR_DEC_GENERIC", len);
		}

		public static byte[] UnescapeLuaString(string str)
		{
			var bytes = new List<byte>();
			int i     = 0;

			while (i < str.Length)
			{
				char cur = str[i++];
				if (cur != '\\') { bytes.Add((byte)cur); continue; }

				char next = str[i++];
				switch (next)
				{
					case 'a':  bytes.Add((byte)'\a'); break;
					case 'b':  bytes.Add((byte)'\b'); break;
					case 'f':  bytes.Add((byte)'\f'); break;
					case 'n':  bytes.Add((byte)'\n'); break;
					case 'r':  bytes.Add((byte)'\r'); break;
					case 't':  bytes.Add((byte)'\t'); break;
					case 'v':  bytes.Add((byte)'\v'); break;
					default:
					{
						if (!char.IsDigit(next))
						{
							bytes.Add((byte)next);
						}
						else
						{
							string s = next.ToString();
							for (int j = 0; j < 2; j++, i++)
							{
								if (i == str.Length) break;
								char n = str[i];
								if (char.IsDigit(n)) s += n; else break;
							}
							bytes.Add((byte)int.Parse(s));
						}
						break;
					}
				}
			}
			return bytes.ToArray();
		}

		// Applies replacements in reverse index order so earlier positions
		// are not shifted by replacements at later positions.
		private void ApplyReplacements(List<(int index, int length, string replacement)> replacements)
		{
			for (int i = replacements.Count - 1; i >= 0; i--)
			{
				var (index, length, replacement) = replacements[i];
				_src = _src.Substring(0, index) + replacement + _src.Substring(index + length);
			}
		}

		private byte[] GetMatchBytes(Match m)
		{
			string captured = m.Groups[2].Value + m.Groups[4].Value;
			if (captured.StartsWith("[STR_ENCRYPT]"))
				captured = captured.Substring(13);

			return m.Groups[2].Value != ""
				? UnescapeLuaString(captured)
				: _luaEncoding.GetBytes(captured);
		}

		public string EncryptStrings()
		{
			if (_settings.EncryptStrings)
			{
				var matches = EncRegex.Matches(_src);
				// One shared decryptor for all strings in this mode —
				// each string is independently RC4'd with the same key.
				// An attacker who recovers the key for one string gets all of them,
				// but that already requires defeating RC4 with no known plaintext.
				Decryptor dec = GenerateGenericDecryptor(matches);

				var replacements = new List<(int, int, string)>();
				foreach (Match m in matches)
					replacements.Add((m.Index, m.Length, dec.Encrypt(GetMatchBytes(m))));

				ApplyReplacements(replacements);
			}
			else
			{
				// Only encrypt strings explicitly tagged [STR_ENCRYPT].
				// Each tagged string gets its own independent Decryptor (independent key).
				var matches = EncRegex.Matches(_src);
				var replacements = new List<(int, int, string)>();
				int n = 0;

				foreach (Match m in matches)
				{
					string captured = m.Groups[2].Value + m.Groups[4].Value;
					if (!captured.StartsWith("[STR_ENCRYPT]")) continue;

					// Independent key per string — recovering one key reveals nothing
					// about any other encrypted string
					Decryptor dec = new Decryptor("IRONBREW_STR_ENCRYPT" + n++, m.Length);
					replacements.Add((m.Index, m.Length, dec.Encrypt(GetMatchBytes(m))));
				}

				ApplyReplacements(replacements);
			}

			if (_settings.EncryptImportantStrings)
			{
				var matches = EncRegex.Matches(_src);
				var replacements = new List<(int, int, string)>();
				int n = 0;

				List<string> sTerms = new List<string> { "http", "function", "metatable", "local" };

				foreach (Match m in matches)
				{
					string captured = (m.Groups[2].Value + m.Groups[4].Value).ToLower();
					if (captured.StartsWith("[str_encrypt]")) captured = captured.Substring(13);
					if (!sTerms.Any(t => captured.Contains(t))) continue;

					Decryptor dec = new Decryptor("IRONBREW_STR_ENCRYPT_IMPORTANT" + n++, m.Length);
					replacements.Add((m.Index, m.Length, dec.Encrypt(GetMatchBytes(m))));
				}

				ApplyReplacements(replacements);
			}

			return _src;
		}

		public ConstantEncryption(ObfuscationSettings settings, string source)
		{
			_settings = settings;
			_src      = source;
		}
	}
}
